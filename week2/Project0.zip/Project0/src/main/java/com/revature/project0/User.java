package com.revature.project0;

public abstract class User {
	
	public abstract boolean login(int id,String password);
	
	public abstract void createCustomerAcc();

	public boolean login(String id, String password) {
		// TODO Auto-generated method stub
		return false;
	}

}