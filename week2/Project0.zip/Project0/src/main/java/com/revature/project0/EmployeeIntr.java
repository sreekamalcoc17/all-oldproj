package com.revature.project0;

public interface EmployeeIntr {
	
	void viewCustomerDetails();
	void viewLogs();
	void acceptReject();
	//boolean login(String id, String password);

}
